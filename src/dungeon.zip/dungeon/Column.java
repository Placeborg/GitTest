package dungeon;

import java.util.ArrayList;
import java.util.List;

class Column {

	List<Room> floorList = new ArrayList<Room>();

}