package dungeon;

import java.util.Scanner;
//import java.awt.Dimension;
//import javax.swing.JFrame;
//import javax.swing.JPanel;

public class Main {

	public static void main(String[] args) {
//		JFrame frame = new JFrame("Dangers & Dungeons");
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//		JPanel p = new JPanel();
//		p.setPreferredSize(new Dimension(600, 600));
//
//		frame.getContentPane().add(p);
//		frame.setExtendedState(frame.getExtendedState() | JFrame.MAXIMIZED_BOTH);
//		frame.setVisible(true);

		Scanner input = new Scanner(System.in);

		// Create World (max. xyz)
		World currentWorld = new World(10, 10, 10);

		// Get player name and allocate player
		System.out.println("Please insert your name.");
		Player player = new Player(input.next());
		player.loc = currentWorld.playerLoc;

		// Start the game
		System.out.println("\n" + player.name + ", you enter a dungeon...");
		// let the player navigate the dungeon
		currentWorld.crawlDungeon(player);

		input.close();
	}
}