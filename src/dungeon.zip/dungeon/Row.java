package dungeon;

import java.util.ArrayList;
import java.util.List;

class Row {

	List<Column> columnList = new ArrayList<Column>();

}